export class teacher
{
    fname:string;
    lname:string;
    address:number;
    contact_number:string;
    yearOfExp:number;
    email:string;
    password:string;
    confirm_password:string;

constructor()
{
    
}

}
