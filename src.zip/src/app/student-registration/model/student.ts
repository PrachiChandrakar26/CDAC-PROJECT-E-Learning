export class student
{
    fname:string;
    lname:string;
    email:string;
    password:string;
    confirm_password:string;

constructor()
{
    
}

}
 