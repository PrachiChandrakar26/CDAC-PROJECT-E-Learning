export class student
{
    email:string;
    password:string;
  
constructor()
{
    
}

}
