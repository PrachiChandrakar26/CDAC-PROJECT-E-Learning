export class teacher
{
    email:string;
    password:string;
  
constructor()
{
    
}

}
