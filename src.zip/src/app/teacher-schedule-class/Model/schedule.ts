import { Time } from "@angular/common";

export class schedule
{
    classname:string;
    subject:string;
    topic:string;
    class_date:Date;
    time:Time;
    class_Link:string;
    "teacher":{
        teacher_id:number;
    }
constructor()
{
    
}

}
